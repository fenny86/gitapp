package utile;

import java.sql.SQLException;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class ConnectionSSMS {
	public static HikariDataSource createMSSQLConnection() {
		HikariConfig config = new HikariConfig("D:\\java\\DemoServlet\\src\\main\\java\\jdbc.properties");
		HikariDataSource ds = new HikariDataSource(config);
		return ds;
		
	}
	
	public static void main(String[] args) {
		try {
			createMSSQLConnection().getConnection();
			System.out.println("連線成功");
		} catch (SQLException e) {
			System.out.println("連線失敗");
		}
		
	}
}
