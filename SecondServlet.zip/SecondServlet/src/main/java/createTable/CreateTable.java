package createTable;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;

import utile.ConnectionSMMS;

public class CreateTable {

	
	public static void main(String args[]) {
		QueryRunner queryRunner=new QueryRunner(ConnectionSMMS.createMSSQLConnection());
		
		String sql="Create TABLE ClassTables "
				+ "(classId int Primary Key, "
				+ " className			varchar(50), " 
				+ " classTeacher    	varchar(28), " 
				+ " classPrice			Money, "
				+ " discount   		    Money," 
				+ " classPicture		varbinary(max), "
				+ " classCategory		varchar(28), " 
				+ " )";
		try {
			queryRunner.update(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
	}
}

