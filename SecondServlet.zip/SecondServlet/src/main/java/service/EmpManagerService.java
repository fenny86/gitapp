package service;

import bean.EmpManager;

public interface EmpManagerService {
	public EmpManager login(String username,String password);

}
